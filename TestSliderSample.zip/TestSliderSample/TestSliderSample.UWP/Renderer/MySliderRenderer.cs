﻿using Microsoft.Graphics.Canvas;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestSliderSample;
using TestSliderSample.UWP.Renderer;
using Windows.Graphics.Imaging;
using Windows.Storage;
using Windows.UI;
using Windows.UI.Xaml.Media.Imaging;
using Xamarin.Forms;
using Xamarin.Forms.Platform.UWP;

[assembly: ExportRenderer(typeof(CustomSlider), typeof(MySliderRenderer))]
namespace TestSliderSample.UWP.Renderer
{
    public class MySliderRenderer : SliderRenderer
    {
        public CustomSlider View { get; set; }
        double currentValue = 0;
        bool isTapped = false;
        protected override void OnElementChanged(ElementChangedEventArgs<Slider> e)
        {
            base.OnElementChanged(e);
            if (e.OldElement != null || e.NewElement == null)
            {
                return;
            }

            View = (CustomSlider)Element;
            if (!string.IsNullOrEmpty(View.ThumbImageIcon))
            {    //
                var thumbImage = View.ThumbImageIcon;

                if (thumbImage == null)
                {
                    Control.ThumbImageSource = null;
                    return;
                }

                BitmapImage bitmapImage = new BitmapImage();
                bitmapImage.UriSource = new Uri("ms-appx:///Assets/" + View.ThumbImageIcon+".png");
                Control.ThumbImageSource = bitmapImage;
                Control.Tapped += Control_Tapped;
                currentValue = Control.Value;
                
                
            }
        }

        private void Control_Tapped(object sender, Windows.UI.Xaml.Input.TappedRoutedEventArgs e)
        {
            this.isTapped = true;
        }

        protected override void OnElementPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            base.OnElementPropertyChanged(sender, e);
            BitmapImage bitmapImage = new BitmapImage();
            bitmapImage.UriSource = new Uri("ms-appx:///Assets/" + View.ThumbImageIcon + ".png");
            Control.ThumbImageSource = bitmapImage;
            if(isTapped == true)
            {
                Control.Value = currentValue;

            }
            else
            {
                currentValue = Control.Value;
            }
            //this.SetText(View.ThumbImageIcon, "0%");
            this.isTapped = false;
        }

        private async void SetText(string img,string text)
        {
            Uri imageuri = new Uri("ms-appx:///Assets/"+ img+".png");
            StorageFile inputFile = await StorageFile.GetFileFromApplicationUriAsync(imageuri);
            BitmapDecoder imagedecoder;
            using (var imagestream = await inputFile.OpenAsync(FileAccessMode.Read))
            {
                imagedecoder = await BitmapDecoder.CreateAsync(imagestream);
            }
            CanvasDevice device = CanvasDevice.GetSharedDevice();
            CanvasRenderTarget renderTarget = new CanvasRenderTarget(device, imagedecoder.PixelWidth, imagedecoder.PixelHeight, 96);
            using (var ds = renderTarget.CreateDrawingSession())
            {
                ds.Clear(Colors.White);
                CanvasBitmap image = await CanvasBitmap.LoadAsync(device, inputFile.Path, 96);
                ds.DrawImage(image);
                ds.DrawText(text, new System.Numerics.Vector2(150, 150), Colors.White);
            }
            string filename = img + ".png";
            StorageFolder pictureFolder = KnownFolders.SavedPictures;
            var file = await ApplicationData.Current.LocalFolder.CreateFileAsync(filename, CreationCollisionOption.ReplaceExisting);
            using (var fileStream = await file.OpenAsync(FileAccessMode.ReadWrite))
            {
                var image = new BitmapImage();
                await image.SetSourceAsync(fileStream);
                Control.ThumbImageSource = image;
                //await renderTarget.SaveAsync(fileStream, CanvasBitmapFileFormat.Png, 1f);
            }
        }
    }
}
